USB Benchmark Application 
-------------------------
The benchmark application is designed to work with specific hardware.
Any attempt to use this application on a usb device that was not 
designed for it will produce unpredictable result.

The Benchmark device firmware is available for a PIC18Fxx5x USB MicroChip� microcontroller.
Download the Benchmark device firmware at www.picmicrochip.com.
