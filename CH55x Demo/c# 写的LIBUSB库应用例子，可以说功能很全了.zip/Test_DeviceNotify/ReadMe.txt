USB Test_DeviceNotify Application 
---------------------------------
The Test_DeviceNotify application listens for system-wide WM_DEVICECHANGE events of USB DEVICEINTERFACE, PORT, and VOLUME notifications.
Test_DeviceNotify does not require any special USB hardware to operate.
