//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Main.rc
//
#define IDC_MYICON                      2
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDI_Main                        107
#define IDI_SMALL                       108
#define IDC_PRAMFRAME                   109
#define IDD_MainWnd                     129
#define IDD_IAPDEMO_DIALOG           129
#define IDC_InformationShow             1000
#define IDC_DownloadType                1001
#define IDC_DnInterface                 1001
#define IDC_ClearShow                   1002
#define IDC_Download                    1002
#define IDC_AboutBox                    1003
#define IDC_DownloadFile                1004
#define IDC_ScanDev                     1005
#define IDC_ClearResult                 1006
#define IDC_ResultShow                  1007
#define IDC_SelectFile                  1008
#define IDC_DeviceList                  1009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
