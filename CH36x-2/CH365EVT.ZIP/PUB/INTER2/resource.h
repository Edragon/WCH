//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CH365IntExam.rc
//
#define IDC_MYICON                      2
#define IDD_MAIN                        101
#define IDD_CH365INTEXAM_DIALOG         102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDI_CH365INTEXAM                107
#define IDI_SMALL                       108
#define IDC_CH365INTEXAM                109
#define IDR_MAINFRAME                   128
#define IDC_OPEN                        1000
#define IDC_CLOSE                       1001
#define IDC_EDTDEVVER                   1003
#define IDC_EDTDLLVER                   1004
#define IDC_EDTBASEADDR                 1009
#define IDC_EDTINTLINE                  1011
#define IDC_EDTCOUNT                    1012
#define IDC_EDITMEM                     1016
#define IDC_DevIndex                    1018
#define IDC_Dev0Frame                   1019
#define IDC_STATIC2                     1020
#define IDC_COUNT                       1021
#define IDC_COUNT2                      1022
#define IDC_InformationShow             1023
#define IDC_ClearShow                   1024
#define IDC_OPEN2                       1029
#define IDC_CLOSE2                      1030
#define IDC_EDTBASEADDR2                1031
#define IDC_EDITMEM2                    1032
#define IDC_EDTINTLINE2                 1033
#define IDC_EDTCOUNT2                   1034
#define IDC_DevIndex2                   1037
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
