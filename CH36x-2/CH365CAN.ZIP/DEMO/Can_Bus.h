// Can_Bus.h : main header file for the CAN_BUS application
//

#if !defined(AFX_CAN_BUS_H__9954E440_2E0E_4458_B1B8_71F706A39FBB__INCLUDED_)
#define AFX_CAN_BUS_H__9954E440_2E0E_4458_B1B8_71F706A39FBB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CCan_BusApp:
// See Can_Bus.cpp for the implementation of this class
//

class CCan_BusApp : public CWinApp
{
public:
	CCan_BusApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCan_BusApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CCan_BusApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CAN_BUS_H__9954E440_2E0E_4458_B1B8_71F706A39FBB__INCLUDED_)
