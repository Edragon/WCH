// Can_BusDlg.h : header file
//
//#include "Ch365can.h"
#if !defined(AFX_CAN_BUSDLG_H__153DFBCE_3A98_4C5B_918E_DCFBCB737080__INCLUDED_)
#define AFX_CAN_BUSDLG_H__153DFBCE_3A98_4C5B_918E_DCFBCB737080__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CCan_BusDlg dialog
typedef		VOID	( * mPCH365_INT_ROUTINE ) ( VOID );		// �жϷ������

UINT CH365Rece_thread(LPVOID pDlg);//�̺߳���

class CCan_BusDlg : public CDialog
{
// Construction
public:
	CCan_BusDlg(CWnd* pParent = NULL);	// standard constructor
public:

	UCHAR		m_DebugMode	;
	UCHAR		m_FrameMode	;
	DWORD		ThreadID;
	BOOL		m_ThreadOp;
	BOOL		m_DeviceStatus;
	BOOL		K_Return;
public:
	UCHAR			iRegion		;//��������
	UCHAR			iSubId		;//�������
	UCHAR			iFunc		;//���ܴ���
	UCHAR			iExFunc		;//������չ
	PUCHAR			m_Data		;//������
	UCHAR			iMode		;
// Dialog Data
	//{{AFX_DATA(CCan_BusDlg)
	enum { IDD = IDD_CAN_BUS_DIALOG };
	CButton	m_OpenCtrl;
	CButton	m_SendCtrl;
	CButton	m_TestCtrl;
	CButton	m_Radio_Data;
	CListBox	m_ListCtrl;
	CEdit	m_DataCtrl;
	CComboBox	m_NameCtrl;
	CComboBox	m_FuncCtrl;
	CString	m_Mode;
	CString	m_Status;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCan_BusDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CCan_BusDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnRadioData();
	afx_msg void OnRadioRemot();
	afx_msg void OnCheckTest();
	afx_msg void OnButtonOpen();
	afx_msg void OnCancel();
	afx_msg void OnButtonSend();
	afx_msg void OnButtonClear();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};



//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CAN_BUSDLG_H__153DFBCE_3A98_4C5B_918E_DCFBCB737080__INCLUDED_)
