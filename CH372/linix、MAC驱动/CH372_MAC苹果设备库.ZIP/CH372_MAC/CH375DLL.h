//
//  CH375DLL.h
//  CH375Lib
//
//  Created by  on 14-5-8.
//  Copyright (c) 2014年 __MyCompanyName__. All rights reserved.
//

#ifndef CH375Lib_CH375DLL_h
#define CH375Lib_CH375DLL_h

#ifdef __cplusplus
extern "C" {
#endif
    
    typedef void (__stdcall* pCH375NotifyRoutine) (int32_t nEvents);
    //CALLBACK_API_STDCALL(void, pCH375NotifyRoutine(int nEvents)) ;
    
    
    int     CH375OpenDevice(UInt32 locationID);
    void    CH375CloseDevice(UInt32 locationID);
    UInt32  CH375GetVersion(void);
    bool    CH375ResetDevice(UInt32 locationID);
    bool    CH375GetDeviceDscr(UInt32 locationID, char* oBuffer, UInt32* ioLength);
    bool    CH375GetConfigDscr(UInt32 locationID, char* oBuffer, UInt32* ioLength);
    bool    CH375ReadInter(UInt32 locationID, char* oBuffer, UInt32* ioLength);
    bool    CH375AbortInter(UInt32 locationID);
    bool     CH375WriteData(UInt32 locationID, char* buffer, UInt32* ioLength);
    bool    CH375AbortWrite(UInt32 locationID);
    bool     CH375ReadData(UInt32 locationID, char* buffer, UInt32 *ioLength);
    bool    CH375AbortRead(UInt32 locationID);
    bool    CH375SetTimeout(UInt32 locationID, int32_t iWrite, int32_t iRead);
    bool    CH375WriteAuxData(UInt32 locationID, char* iBuffer, UInt32* ioLength);
//    bool    CH375SetExclusive(int nIndex);
    UInt32    CH375GetUsbID(UInt32 locationID);

    int     CH375GetDeviceLocation(UInt32** locationID); // this function is used to acuqire the locationID all existed. must call free() after you don't need any more
    bool    CH375SetBufUpload(UInt32 locationID, bool bEnable);
    int32_t CH375QueryBufUpload(UInt32 locationID);
    bool    CH375SetBufDownload(UInt32 locationID, bool bEnable);
    int32_t CH375QueryBufDownload(UInt32 locationID);
    
    bool    CH375ResetInter(UInt32 locationID);
    bool    CH375ResetAux(UInt32 locationID);
    bool    CH375ResetRead(UInt32 locationID);
    bool    CH375ResetWrite(UInt32 locationID);
    bool    CH375SetDeviceNotify(pCH375NotifyRoutine routine);
    
#ifdef __cplusplus
}
#endif


#endif
