// CH372UpDownDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CH372UpDown.h"
#include "CH372UpDownDlg.h"
#include "CH375DLL.H"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	
// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCH372UpDownDlg dialog

CCH372UpDownDlg::CCH372UpDownDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCH372UpDownDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCH372UpDownDlg)
	m_uplen1 = 0;
	m_uplen2 = 0;
	m_downdata2 = _T("");
	m_downlen2 = 0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_open = FALSE;
	m_close = FALSE;
	mIndex = 0;
		//�����ʼ��
	T2DHandle = INVALID_HANDLE_VALUE;    
	T2UHandle = INVALID_HANDLE_VALUE;  
	T1Handle = INVALID_HANDLE_VALUE;
}

void CCH372UpDownDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCH372UpDownDlg)
	DDX_Control(pDX, IDC_BUTTON2_UP, m_btnup2);
	DDX_Control(pDX, IDC_BUTTON2_DOWN, m_btndown2);
	DDX_Control(pDX, IDC_BUTTON1_UP, m_btnup1);
	DDX_Control(pDX, IDC_LIST2_UPDATA, m_listup2);
	DDX_Control(pDX, IDC_LIST1_UPDATA, m_listup1);
	DDX_Text(pDX, IDC_EDIT1_UPLEN, m_uplen1);
	DDX_Text(pDX, IDC_EDIT2_UPLEN, m_uplen2);
	DDX_Text(pDX, IDC_EDIT2_DOWNDATA, m_downdata2);
	DDX_Text(pDX, IDC_EDIT2_DOWNLEN, m_downlen2);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CCH372UpDownDlg, CDialog)
	//{{AFX_MSG_MAP(CCH372UpDownDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON2_DOWN, OnButton2Down)
	ON_BN_CLICKED(IDC_BUTTON2_UP, OnButton2Up)
	ON_BN_CLICKED(IDC_BUTTON1_UP, OnButton1Up)
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCH372UpDownDlg message handlers

BOOL CCH372UpDownDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_trdup1 = FALSE;
	m_trdup2 = FALSE;
	m_trddown2 = FALSE;
	m_downdata2 = _T("");
	m_downlen2 = 0;
	m_uplen1 = 8;
	m_uplen2 = 32;
	if ( CH375OpenDevice( mIndex ) == INVALID_HANDLE_VALUE )   // ʹ��֮ǰ������豸 
	{
		MessageBox("���豸ʧ�ܣ�","DEBUG372",MB_OK|MB_ICONSTOP);
		m_open = FALSE;
	}
	else
	{
		m_open = TRUE;
	}
	UpdateData(FALSE);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CCH372UpDownDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCH372UpDownDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CCH372UpDownDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CCH372UpDownDlg::OnButton2Down()	//�˵�2�´�
{
	UpdateData(TRUE);
	CWinThread * mTrdDown2 = NULL;
	if(!m_open)	
	{
		if ( CH375OpenDevice( mIndex ) == INVALID_HANDLE_VALUE )   // ʹ��֮ǰ������豸 
		{
			MessageBox("���豸ʧ�ܣ�","DEBUG372",MB_OK|MB_ICONSTOP);
			return;
		}
		m_open = TRUE;
	}
	if(T2DHandle == INVALID_HANDLE_VALUE)
	{
		UCHAR DeviceName[128];
		memcpy(&DeviceName[0],CH375GetDeviceName(mIndex),sizeof(DeviceName));
		T2DHandle = CreateFile( (char *)&DeviceName[0], GENERIC_READ | GENERIC_WRITE,  // ���豸
										FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL );
		if(T2DHandle == INVALID_HANDLE_VALUE)
		{
			MessageBox("�޷����豸��","DEBUG372",MB_OK|MB_ICONSTOP);
			return;
		}
	}

	if(m_downlen2 >= mCH375_PACKET_LENGTH*8*2)
	{
		MessageBox("�������´����ݳ��ȣ�","DEBUG372",MB_OK);
		return;
	}
	
	mTrdDown2 = AfxBeginThread(mThreadDown2,this,THREAD_PRIORITY_NORMAL,0,0,NULL); 
	if(mTrdDown2)
	{
		m_trddown2 = TRUE;		//�߳�������־
	}
	else
	{
		MessageBox("�˵�2�´��߳�����ʧ��","DEBUG372",MB_OK|MB_ICONSTOP);
		m_trddown2 = FALSE;
		return;
	}
}

UINT mThreadDown2(LPVOID pParam)		//�˵�2�´��߳�
{
	ULONG dlen,datalen;
	UCHAR mBuf[mCH375_PACKET_LENGTH*8];

	CCH372UpDownDlg *pDlg = (CCH372UpDownDlg *)pParam;
	pDlg->m_btndown2.EnableWindow(FALSE);
	if(pDlg->m_open && pDlg->m_trddown2)
	{
		/**************���߳�����CreateFile���豸,��Ϊÿ�����ͬһʱ��ֻ��ִ��һ��API**************************/
		
		if ( pDlg->T2DHandle != INVALID_HANDLE_VALUE ) 
		{
			datalen = strlen(pDlg->m_downdata2);
			if((LONG)datalen/2 > pDlg->m_downlen2)		//ȡ���ݳ��������볤����ƫСֵ
				datalen = pDlg->m_downlen2;		
			else datalen = datalen/2;

			memcpy(mBuf,pDlg->m_downdata2,datalen*2);
			pDlg->mStrtoVal(&mBuf[0],datalen*2);
			dlen = datalen;

			if(!CH375WriteData((ULONG)pDlg->T2DHandle,&mBuf[0],&dlen))
			{
				if ( !pDlg->m_close ) MessageBox(NULL,"�˵�2�´�ʧ�ܣ�����豸�Ͽ�����ô���ȹرձ�����","DEBUG372",MB_OK|MB_ICONSTOP);
			}
			
		}
	}
	pDlg->m_btndown2.EnableWindow(TRUE);
	pDlg->m_trddown2 = FALSE;
	ExitThread(0);
	return 0;
}

void CCH372UpDownDlg::OnButton2Up()		//�˵�2�ϴ�
{
	CWinThread * mTrdUp2 = NULL;
	UpdateData(TRUE);
	if(!m_open)	
	{
		if ( CH375OpenDevice( mIndex ) == INVALID_HANDLE_VALUE )   // ʹ��֮ǰ������豸 
		{
			MessageBox("���豸ʧ�ܣ�","DEBUG372",MB_OK|MB_ICONSTOP);
			return;
		}
		m_open = TRUE;
	}

	if(T2UHandle == INVALID_HANDLE_VALUE)
	{
		UCHAR DeviceName[128];
		memcpy(&DeviceName[0],CH375GetDeviceName(mIndex),sizeof(DeviceName));
		T2UHandle = CreateFile( (char *)&DeviceName[0], GENERIC_READ | GENERIC_WRITE,  // ���豸
									FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL );
		if(T2UHandle == INVALID_HANDLE_VALUE)
		{
			MessageBox("�޷����豸��","DEBUG372",MB_OK|MB_ICONSTOP);
			return;
		}
	}

	if(m_uplen2 == 0 || m_uplen2 > mCH375_PACKET_LENGTH*8 )
	{
		MessageBox("�������ϴ����ȣ�","DEBUG372",MB_OK);
		return;
	}
	mTrdUp2 = AfxBeginThread(mThreadUp2,this,THREAD_PRIORITY_NORMAL,0,0,NULL); 
	if(mTrdUp2)
	{
		m_trdup2 = TRUE;		//�߳�������־
	}
	else
	{
		MessageBox("�˵�2�ϴ��߳�����ʧ��","DEBUG372",MB_OK|MB_ICONSTOP);
		m_trdup2 = FALSE;
		return;
	}
	Sleep(10);
	UpdateData(FALSE);
}

UINT mThreadUp2(LPVOID pParam)		//�˵�2�ϴ��߳�
{
	UCHAR mBuf[mCH375_PACKET_LENGTH*8];
	ULONG dlen,datalen;	
	CCH372UpDownDlg *pDlg = (CCH372UpDownDlg *)pParam;
	pDlg->m_btnup2.EnableWindow(FALSE);

	if(pDlg->m_open && pDlg->m_trdup2)		//�豸�򿪣��߳�����
	{
	/**************���߳�����CreateFile���豸,��Ϊÿ�����ͬһʱ��ֻ��ִ��һ��API**************************/
		
		if ( pDlg->T2UHandle != INVALID_HANDLE_VALUE ) 
		{  // ���豸�ɹ�
	
			datalen = min( pDlg->m_uplen2, sizeof(mBuf));
			dlen = datalen;

			if(CH375ReadData((ULONG)pDlg->T2UHandle,&mBuf[0],&dlen))
			{					//�����ɹ��������
				CHAR buffer[mCH375_PACKET_LENGTH*8*2+1];
				ULONG i,j;
				for(i=0,j=0;i<dlen;i++)
				{
					sprintf(&buffer[j],"%02X",mBuf[i]);
					j += 2;
				}
				buffer[j] = '\0';
				pDlg->m_listup2.InsertString(-1,buffer);
				pDlg->m_uplen2 = dlen;
			}
			else if ( !pDlg->m_close ) MessageBox(NULL,"�˵�2�ϴ�ʧ�ܣ�����豸�Ͽ�����ô���ȹرձ�����","DEBUG372",MB_OK|MB_ICONSTOP);
		}
	}
	pDlg->m_btnup2.EnableWindow(TRUE);
	pDlg->m_trdup2 = FALSE;
	ExitThread(0);
	return 0;
}

void CCH372UpDownDlg::OnButton1Up()		//�˵�1�ϴ�
{
	CWinThread * mTrdUp1 = NULL;
	UpdateData(TRUE);
	if(!m_open)	
	{
		if ( CH375OpenDevice( mIndex ) == INVALID_HANDLE_VALUE )   // ʹ��֮ǰ������豸 
		{
			MessageBox("���豸ʧ�ܣ�","DEBUG372",MB_OK|MB_ICONSTOP);
			return;
		}
		m_open = TRUE;
	}

	if(T1Handle == INVALID_HANDLE_VALUE)
	{
		UCHAR DeviceName[128];
		memcpy(&DeviceName[0],CH375GetDeviceName(mIndex),sizeof(DeviceName));
		T1Handle = CreateFile( (char *)&DeviceName[0], GENERIC_READ | GENERIC_WRITE,  // ���豸
									FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL );
		if(T1Handle == INVALID_HANDLE_VALUE)
		{
			MessageBox("�޷����豸��","DEBUG372",MB_OK|MB_ICONSTOP);
			return;
		}
	}

	if((m_uplen1 == 0) || (m_uplen1 > 8))
	{
		MessageBox("���������ϴ����ȣ����Ȳ�����8","DEBUG372",MB_OK);
		return;
	}
	mTrdUp1 = AfxBeginThread(mThreadUp1,this,THREAD_PRIORITY_NORMAL,0,0,NULL); 
	if(mTrdUp1)
	{
		m_trdup1 = TRUE;		//�߳�������־
	}
	else
	{
		MessageBox("�˵�1�ϴ��߳�����ʧ��","DEBUG372",MB_OK|MB_ICONSTOP);
		m_trdup1 = FALSE;
		return;
	}
	Sleep(10);
	UpdateData(FALSE);
}

UINT mThreadUp1(LPVOID pParam)		//�˵�1�ϴ��߳�
{
	UCHAR mBuf[mCH375_PACKET_LENGTH*8];
	ULONG dlen,datalen;

	CCH372UpDownDlg *pDlg = (CCH372UpDownDlg *)pParam;
	pDlg->m_btnup1.EnableWindow(FALSE);

	if(pDlg->m_open && pDlg->m_trdup1)
	{
		/**************���߳�����CreateFile���豸,��Ϊÿ�����ͬһʱ��ֻ��ִ��һ��API**************************/

		if ( pDlg->T1Handle != INVALID_HANDLE_VALUE ) 
		{
			datalen = pDlg->m_uplen1;
			dlen = datalen;
			if(CH375ReadInter((ULONG)pDlg->T1Handle,&mBuf,&dlen))
			{
				CHAR buffer[mCH375_PACKET_LENGTH*8*2+1];
				ULONG i,j;
				for(i=0,j=0;i<dlen;i++)
				{
					sprintf(&buffer[j],"%02X",mBuf[i]);
					j += 2;
				}
				buffer[j] = '\0';
				SetDlgItemText(pDlg->m_hWnd,IDC_EDIT1_UPDATA,buffer);
				pDlg->m_uplen1 = dlen;
			}
			else if ( !pDlg->m_close ) MessageBox(NULL,"�˵�1�ϴ�ʧ�ܣ�����豸�Ͽ�����ô���ȹرձ�����","DEBUG372",MB_OK|MB_ICONSTOP);
		}
	}
	pDlg->m_btnup1.EnableWindow(TRUE);
	pDlg->m_trdup1 = FALSE;
	ExitThread(0);
	return 0;
}

PUCHAR CCH372UpDownDlg::mStrtoVal(PUCHAR str, ULONG strlen)
{
	ULONG i,j;
	ULONG len;
	UCHAR strRev[mMAX_BUFFER_LENGTH];
	if( strlen % 2 != 0 )
	{
		str[strlen] = 0;
		strlen += 1;
	}
	len = strlen / 2;
	for(i=0,j=0;i<strlen;i++,j++)
	{
		strRev[j] = (UCHAR)((mCharToBcd(str[i])<<4) + mCharToBcd(str[i+1]));
		i++;
	}
	strRev[j]='\0';
	memcpy(  str,strRev,len);
	return str;
}

UCHAR CCH372UpDownDlg::mCharToBcd(UCHAR iChar)
{
	UCHAR	mBCD;
	if ( iChar >= '0' && iChar <= '9' ) mBCD = iChar -'0';
	else if ( iChar >= 'A' && iChar <= 'F' ) mBCD = iChar - 'A' + 0x0a;
	else if ( iChar >= 'a' && iChar <= 'f' ) mBCD = iChar - 'a' + 0x0a;
//	else mBCD = 0xff;
	else mBCD = 0;
	return( mBCD );
}

void CCH372UpDownDlg::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	mCloseWin();
	CDialog::OnClose();
}

//�˳�����ر��豸���߳ǡ����
void CCH372UpDownDlg::mCloseWin()
{
	m_close = TRUE;
	if(m_open)  // �˳�δ��ɵ��߳�,�ر��豸
	{
		if(m_trddown2)
		{
			CH375AbortWrite(mIndex);
		}
		if(m_trdup2)
		{
			CH375AbortRead(mIndex);
		}
		if(m_trdup1)
		{
			CH375AbortInter(mIndex);
		}
		Sleep(50);
		if ( T2DHandle != INVALID_HANDLE_VALUE )
		{
			CloseHandle( T2DHandle );		//�رն˵�2�´����
		}
		if ( T2UHandle != INVALID_HANDLE_VALUE )
		{
			CloseHandle( T2UHandle );		//�رն˵�2�ϴ����
		}
		if ( T1Handle != INVALID_HANDLE_VALUE )
		{
			CloseHandle( T1Handle );		//�رն˵�1���
		}
		CH375CloseDevice(mIndex);
		m_open=FALSE;
		Sleep(20);
	}
}

BOOL CCH372UpDownDlg::DestroyWindow() 
{
	// TODO: Add your specialized code here and/or call the base class
	mCloseWin();
	return CDialog::DestroyWindow();
}
