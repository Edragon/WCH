//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Demo.RC
//
#define VER_DEBUG                       0
#define VER_PRERELEASE                  0
#define VER_PRODUCTBUILD_QFE            12
#define VER_PRODUCTVERSION_W            0x0114
#define IDC_WordRomove                  1002
#define IDC_IDC_SegUnLight              1041
#define IDC_IDC_SegUnLight3             1043
#define IDC_BUTTON1                     1046
#define IDC_SetSegLight                 1046
#define IDC_CHECK1                      1048
#define IDC_BCDCoding                   1048
#define IDC_BUTTON2                     1049
#define IDC_SetShowPara                 1049
#define IDC_SLIDER1                     1052
#define IDC_LimitVal                    1054
#define IDC_SegAddr                     1055
#define IDC_cmdcode                     1058
#define VER_PRODUCTBUILD                2004
#define IDC_LoadLightPole               6139
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1059
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
