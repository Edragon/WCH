/********************************** (C) COPYRIGHT *******************************
* File Name          : USB_HOST.C
* Author             : WCH
* Version            : V1.0
* Date               : 2013/11/15
* Description        : CH563 USB_Device Example
*******************************************************************************/



/******************************************************************************/
/* ͷ�ļ����� */
#include  <stdio.h>
#include  <string.h>
#include  "CH563BAS.H"                                                          /* оƬ���Ͷ������ͷ�ļ� */    
#include  "CH563SFR.H"                                                          /* оƬ�Ĵ������ͷ�ļ� */
#include  "CH563USBSFR.H"                                                       /* оƬUSB�Ĵ������ͷ�ļ� */    
#include  "CH563USB.H"                                                          /* USB���ö������ͷ�ļ� */    
#include  "USB_DEVICE.H"                                                        /* USB�豸�������ͷ�ļ� */
#include  "PRINTF.H"                                                            /* ���ڴ�ӡ�������ͷ�ļ� */

/******************************************************************************/
/* �豸������ */
UINT8 MyDevDescr[ ] = { 0x12, 0x01, 0x10, 0x01, 0xFF, 0x80, 0x37, 0x40, 
                        0x48, 0x43, 0x37, 0x55,                                 /* ����ID�Ͳ�ƷID */
                        0x00, 0x01, 0x01, 0x02, 0x00, 0x01 };

/* ȫ������������ */
UINT8 My_FS_CfgDescr[ ] = { 0x09, 0x02, 0x27, 0x00, 0x01, 0x01, 0x00, 0x80, 0x32,
                            0x09, 0x04, 0x00, 0x00, 0x03, 0xFF, 0x80, 0x37, 0x00,
                            0x07, 0x05, 0x82, 0x02, 0x40, 0x00, 0x00,
                            0x07, 0x05, 0x02, 0x02, 0x40, 0x00, 0x00,
                            0x07, 0x05, 0x81, 0x03, 0x08, 0x00, 0x00 };

/* �������������� */
UINT8 My_HS_CfgDescr[ ] = { 0x09, 0x02, 0x27, 0x00, 0x01, 0x01, 0x00, 0x80, 0x32,
                            0x09, 0x04, 0x00, 0x00, 0x03, 0xFF, 0x80, 0x37, 0x00,
                            0x07, 0x05, 0x82, 0x02, 0x00, 0x02, 0x00,
                            0x07, 0x05, 0x02, 0x02, 0x00, 0x02, 0x00,
                            0x07, 0x05, 0x81, 0x03, 0x40, 0x00, 0x00 };

/* ���������� */
UINT8 MyLangDescr[ ] = { 0x04, 0x03, 0x09, 0x04 };

/* ������Ϣ */
UINT8 MyManuInfo[ ] = { 0x0E, 0x03, 'w', 0, 'c', 0, 'h', 0, '.', 0, 'c', 0, 'n', 0 };

/* ��Ʒ��Ϣ */
UINT8 MyProdInfo[ ] = { 0x0C, 0x03, 'C', 0, 'H', 0, '5', 0, '6', 0, '3', 0 };

/******************************************************************************/
/* ������������ */
UINT8V  gUsbConfig;                                                             /* USB�豸���ñ�־ */
UINT8V  gSetupReq;                                                              /* USB���ƴ��������� */    
UINT8V  gSetupLen;                                                              /* USB���ƴ��䴫�䳤�� */
UINT8V  gUsbSpeed;                                                              /* ��ǰUSB�ٶ�(Ĭ��0: ����;1:ȫ��) */    
UINT8   *pDescr;                                                                /* ������ָ�� */        
UINT8V  Speed_Test_Flag;                                                        /* ��ʼ�����ٶȱ�־ */ 
/*******************************************************************************
* Function Name  : USB_Reg_Check
* Description    : ��ȡȫ��USB��ؼĴ���
*                  �ú������ڲ���ʱʹ��,ʵ�ʲ���Ҫ
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/

void USB_Reg_Check( void )
{
#if  MY_DEBUG_PRINTF 
    /* ��ȡ���Ĵ���Ĭ��ֵ */
    printf("Read All USB Registers.............................................................\n");        
    printf("Address(0x000) = %08lx\n",(UINT32)HC_CAPLENGTH);
    printf("Address(0x004) = %08lx\n",(UINT32)HC_HCSPARAMS);
    printf("Address(0x008) = %08lx\n",(UINT32)HC_HCCPARAMS);
    printf("Address(0x010) = %08lx\n",(UINT32)HC_USBCMD);
    printf("Address(0x014) = %08lx\n",(UINT32)HC_USBSTS);
    printf("Address(0x018) = %08lx\n",(UINT32)HC_USBINT_EN);
    printf("Address(0x01C) = %08lx\n",(UINT32)HC_FRINDEX);
    printf("Address(0x024) = %08lx\n",(UINT32)HC_PERIODICLISTBASE);
    printf("Address(0x028) = %08lx\n",(UINT32)HC_ASYNCHRONOUS);
    printf("Address(0x030) = %08lx\n",(UINT32)HC_PORTSC);
    printf("Address(0x040) = %08lx\n",(UINT32)HC_MISCELLANEOUS);
    printf("\n");
    printf("Address(0x080) = %08lx\n",(UINT32)OTG_CONTROL_STATUS);
    printf("Address(0x084) = %08lx\n",(UINT32)OTG_INT_STATUS);
    printf("Address(0x088) = %08lx\n",(UINT32)OTG_INT_EBABLE);
    printf("\n");
    
    printf("Address(0x0C0) = %08lx\n",(UINT32)USB_GL_INT_STATUS);
    printf("Address(0x0C4) = %08lx\n",(UINT32)USB_GL_MASK_INT);
    printf("\n");
    
    printf("Address(0x100) = %08lx\n",(UINT32)USB_DEV_CONTROL);
    printf("Address(0x104) = %08lx\n",(UINT32)USB_DEV_ADDRESS);
    printf("Address(0x108) = %08lx\n",(UINT32)USB_DEV_TEST);
    printf("Address(0x10C) = %08lx\n",(UINT32)USB_DEV_SOF_NUM);
    printf("Address(0x110) = %08lx\n",(UINT32)USB_DEV_SOF_MASKTIMER);
    printf("Address(0x114) = %08lx\n",(UINT32)USB_PHY_TEST_MODE);
    printf("Address(0x118) = %08lx\n",(UINT32)USB_DEV_VCS_CONTROL);
    printf("Address(0x11C) = %08lx\n",(UINT32)USB_DEV_CX_CONF_STATUS);
    printf("Address(0x120) = %08lx\n",(UINT32)USB_DEV_CX_CONF_FIFO_STATUS);
    printf("Address(0x124) = %08lx\n",(UINT32)USB_DEV_IDLE_COUNTER);
    printf("Address(0x130) = %08lx\n",(UINT32)USB_DEV_MASK_INT_GROP);
    printf("Address(0x134) = %08lx\n",(UINT32)USB_DEV_MASK_INT_GROP0);
    printf("Address(0x138) = %08lx\n",(UINT32)USB_DEV_MASK_INT_GROP1);
    printf("Address(0x13C) = %08lx\n",(UINT32)USB_DEV_MASK_INT_GROP2);
    printf("Address(0x140) = %08lx\n",(UINT32)USB_DEV_INT_GROP);
    printf("Address(0x144) = %08lx\n",(UINT32)USB_DEV_INT_GROP0);
    printf("Address(0x148) = %08lx\n",(UINT32)USB_DEV_INT_GROP1);
    printf("Address(0x14C) = %08lx\n",(UINT32)USB_DEV_INT_GROP2);
    printf("Address(0x150) = %08lx\n",(UINT32)USB_DEV_RECV_0_LEN_PACK);
    printf("Address(0x154) = %08lx\n",(UINT32)USB_DEV_SEND_0_LEN_PACK);
    printf("Address(0x158) = %08lx\n",(UINT32)USB_DEV_ISO_ERR_ABORT);
    printf("Address(0x160) = %08lx\n",(UINT32)USB_DEV_EP1_IN_MAXPKS);        
    printf("Address(0x164) = %08lx\n",(UINT32)USB_DEV_EP2_IN_MAXPKS);
    printf("Address(0x168) = %08lx\n",(UINT32)USB_DEV_EP3_IN_MAXPKS);
    printf("Address(0x16C) = %08lx\n",(UINT32)USB_DEV_EP4_IN_MAXPKS);
    printf("Address(0x170) = %08lx\n",(UINT32)USB_DEV_EP5_IN_MAXPKS);
    printf("Address(0x174) = %08lx\n",(UINT32)USB_DEV_EP6_IN_MAXPKS);
    printf("Address(0x178) = %08lx\n",(UINT32)USB_DEV_EP7_IN_MAXPKS);
    printf("Address(0x17C) = %08lx\n",(UINT32)USB_DEV_EP8_IN_MAXPKS);    
    printf("Address(0x180) = %08lx\n",(UINT32)USB_DEV_EP1_OUT_MAXPKS);
    printf("Address(0x184) = %08lx\n",(UINT32)USB_DEV_EP2_OUT_MAXPKS);
    printf("Address(0x188) = %08lx\n",(UINT32)USB_DEV_EP3_OUT_MAXPKS);
    printf("Address(0x18C) = %08lx\n",(UINT32)USB_DEV_EP4_OUT_MAXPKS);
    printf("Address(0x190) = %08lx\n",(UINT32)USB_DEV_EP5_OUT_MAXPKS);
    printf("Address(0x194) = %08lx\n",(UINT32)USB_DEV_EP6_OUT_MAXPKS);
    printf("Address(0x198) = %08lx\n",(UINT32)USB_DEV_EP7_OUT_MAXPKS);
    printf("Address(0x19C) = %08lx\n",(UINT32)USB_DEV_EP8_OUT_MAXPKS);    
    printf("Address(0x1A0) = %08lx\n",(UINT32)USB_DEV_EP1_4_MAP);
    printf("Address(0x1A4) = %08lx\n",(UINT32)USB_DEV_EP5_8_MAP);
    printf("Address(0x1A8) = %08lx\n",(UINT32)USB_DEV_FIFO_MAP);
    printf("Address(0x1AC) = %08lx\n",(UINT32)USB_DEV_FIFO_CONFIG);
    printf("Address(0x1B0) = %08lx\n",(UINT32)USB_DEV_FIFO0_INFO);
    printf("Address(0x1B4) = %08lx\n",(UINT32)USB_DEV_FIFO1_INFO);
    printf("Address(0x1B8) = %08lx\n",(UINT32)USB_DEV_FIFO2_INFO);
    printf("Address(0x1BC) = %08lx\n",(UINT32)USB_DEV_FIFO3_INFO);
    printf("Address(0x1C0) = %08lx\n",(UINT32)USB_DEV_DMA_TARGET_FIFO);
    printf("Address(0x1C8) = %08lx\n",(UINT32)USB_DEV_DMA_SET1);
    printf("Address(0x1CC) = %08lx\n",(UINT32)USB_DEV_DMA_SET2);
    printf("Address(0x1D0) = %08lx\n",(UINT32)USB_DEV_DMA_SET3);
#endif    
}

/*******************************************************************************
* Function Name  : USBDev_ModeSet
* Description    : ���ó�USB�豸ģʽ
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/

void USBDev_ModeSet( void )
{ 
    R8_MISC_CTRL_USB = R8_MISC_CTRL_USB & ( ~RB_MISC_USB_ID_EN );               /* USB OTG ID pin enable */                                    
    R8_MISC_CTRL_USB = R8_MISC_CTRL_USB | RB_MISC_USB_ID_ST;                    /* ���ó�USB�豸 */
}

/*******************************************************************************
* Function Name  : USBDev_SpeedSet
* Description    : USB�豸�ٶ�����
* Input          : speed---USB_DEV_SPEED_HS: ����ģʽ
*                          USB_DEV_SPEED_FS: ȫ��ģʽ
* Output         : None
* Return         : None
*******************************************************************************/

void USBDev_SpeedSet( UINT8 speed )
{
    if( speed == USB_DEV_SPEED_HS )
    {
        USB_DEV_CONTROL &= ~RB_FORCE_FS;                                        /* ����ģʽ(Ĭ��) */
    }
    else
    {
        USB_DEV_CONTROL |= RB_FORCE_FS;                                         /* ȫ��ģʽ */
    }    
}

/*******************************************************************************
* Function Name  : USBDev_SpeedCheck
* Description    : USB�豸�ٶȼ��
* Input          : None
* Output         : None
* Return         : ����0x00---����ģʽ, 0x01---ȫ��ģʽ
*******************************************************************************/

UINT8 USBDev_SpeedCheck( void )
{
     if( USB_DEV_CONTROL & RB_HS_EN )
    {
#if  MY_DEBUG_PRINTF         
        printf("Current Device is HS speed!\n");    
#endif                                    
        gUsbSpeed = 0x00;                                                       /* ��ǰUSB�豸�ٶ�Ϊ���� */
        return( 0x00 );    
    }
    else
    {
#if  MY_DEBUG_PRINTF         
          printf("Current Device is FS speed!\n");
#endif          
        gUsbSpeed = 0x01;                                                       /* ��ǰUSB�豸�ٶ�Ϊȫ�� */
        return( 0x01 );    
    }
}

/*******************************************************************************
* Function Name  : USBDev_UsbInt_Enable
* Description    : USB�豸���USB�ж�ʹ��
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/

void USBDev_UsbInt_Enable( void )  
{
    /* ����USB�ж� */
    R8_INT_EN_IRQ_1 = R8_INT_EN_IRQ_1 | RB_IE_IRQ_USB;                          /* USB�ж�ʹ�� */
    R8_INT_EN_IRQ_GLOB |= RB_IE_IRQ_GLOB;                                       /* ȫ���ж�ʹ�� */
}

/*******************************************************************************
* Function Name  : USBDev_Init
* Description    : USB�豸��ʼ��
*                  ������Ҫ�Ĵ��������ã��˵㡢FIFO����
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/

void USBDev_Init( void )
{
    /* ģ��CH372�豸 */
    /* ENDP1_IN Ϊ�ж϶˵㣬ռ8���ֽڣ�ʹ��FIFO0(IN) */
    /* ENDP2_IN Ϊ�����˵㣬ռ64���ֽڣ�ʹ��FIFO1(IN) */
    /* ENDP2_OUTΪ�����˵㣬ռ64���ֽڣ�ʹ��FIFO2(OUT) */

#if 1
    /* һ�����˵��Լ����FIFO����(�Ĵ���ֱ�����÷�ʽ) */
    USB_DEV_FIFO_CONFIG    = 0x00222223;                                        /* R(0x1AC) */
    USB_DEV_EP1_4_MAP      = 0x33332130;                                        /* R(0x1A0) FIFO0(ENDP1_IN)��FIFO1(ENDP2_IN)��FIFO2(ENDP2_OUT) */         
    USB_DEV_FIFO_MAP       = 0x0F021211;                                        /* R(0x1A8) */                                          
    USB_DEV_EP1_IN_MAXPKS  = 0x00000008;                                        /* R(0x160) EP1_IN_MAXPKS  = 8 bytes */
    USB_DEV_EP2_IN_MAXPKS  = 0x00000040;                                        /* R(0x164) EP2_IN_MAXPKS  = 64 bytes */
    USB_DEV_EP2_OUT_MAXPKS = 0x00000040;                                        /* R(0x184) EP2_OUT_MAXPKS = 64 bytes */    

#if  MY_DEBUG_PRINTF
    printf("Address(0x1AC) = %08lx\n",(UINT32)USB_DEV_FIFO_CONFIG);    
    printf("Address(0x1A0) = %08lx\n",(UINT32)USB_DEV_EP1_4_MAP);
    printf("Address(0x1A8) = %08lx\n",(UINT32)USB_DEV_FIFO_MAP);
    printf("Address(0x160) = %08lx\n",(UINT32)USB_DEV_EP1_IN_MAXPKS);
    printf("Address(0x164) = %08lx\n",(UINT32)USB_DEV_EP2_IN_MAXPKS);
    printf("Address(0x184) = %08lx\n",(UINT32)USB_DEV_EP2_OUT_MAXPKS);    
    printf("Address(0x100) = %08lx\n",(UINT32)USB_DEV_CONTROL);
    printf("Address(0x114) = %08lx\n",(UINT32)USB_PHY_TEST_MODE);
    printf("\n");
#endif

#endif


#if 0        
    /* �������˵��Լ����FIFO����(����������÷�ʽ) */

    /* �˵�1���� */
    USBDev_EPx_Init( ENDP1, 
                     ENDP_TYPE_IN,                                              /* ����ENDP1 IN�˵� */
                     FIFO_TYPE_INTERRUPT,                                       /* �˵�����Ϊ�ж϶˵� */
                     FIFO_DIR_IN,                                               /* FIFO����ΪΪIN */
                     FIFO_BK_NUM_SINGLE,                                        /* FIFO����Ϊ����,���512�ֽ� */    
                     FIFO_BK_SIZE_0,                                            /* FIFO���СС�ڵ���512�ֽ� */
                     FIFO_NUM_0,                                                /* �ö˵��Ӧ��FIFOΪFIFO 0 */
                     FIFO_ENABLE,                                               /* ʹ�ܸö˵��Ӧ��FIFO */
                     USB_EP1_IN_MAX_PKT );                                      /* ���øö˵�������С */
    
    /* �˵�2���� */    
    USBDev_EPx_Init( ENDP2,     
                     ENDP_TYPE_IN,                                              /* ����ENDP2 IN�˵� */
                     FIFO_TYPE_BULK,                                            /* �˵�����Ϊ�����˵� */
                     FIFO_DIR_IN,                                               /* FIFO����ΪΪIN */
                     FIFO_BK_NUM_SINGLE,                                        /* FIFO����Ϊ����,���512�ֽ� */
                     FIFO_BK_SIZE_0,                                            /* FIFO���СС�ڵ���512�ֽ� */    
                     FIFO_NUM_1,                                                /* �ö˵��Ӧ��FIFOΪFIFO 1 */
                     FIFO_ENABLE,                                               /* ʹ�ܸö˵��Ӧ��FIFO */    
                     USB_EP2_IN_MAX_PKT );                                      /* ���øö˵�������С */

    /* �˵�2���� */
    USBDev_EPx_Init( ENDP2, 
                     ENDP_TYPE_OUT,                                             /* ����ENDP2 OUT�˵� */
                     FIFO_TYPE_BULK,                                            /* �˵�����Ϊ�����˵� */
                     FIFO_DIR_OUT,                                              /* FIFO����ΪΪOUT */
                     FIFO_BK_NUM_SINGLE,                                        /* FIFO����Ϊ����,���512�ֽ� */
                     FIFO_BK_SIZE_0,                                            /* FIFO���СС�ڵ���512�ֽ� */    
                     FIFO_NUM_2,                                                /* �ö˵��Ӧ��FIFOΪFIFO 2 */
                     FIFO_ENABLE,                                               /* ʹ�ܸö˵��Ӧ��FIFO */    
                     USB_EP2_OUT_MAX_PKT );                                     /* ���øö˵�������С */

#if  MY_DEBUG_PRINTF
    printf("Address(0x1AC) = %08lx\n",(UINT32)USB_DEV_FIFO_CONFIG);    
    printf("Address(0x1A0) = %08lx\n",(UINT32)USB_DEV_EP1_4_MAP);
    printf("Address(0x1A8) = %08lx\n",(UINT32)USB_DEV_FIFO_MAP);
    printf("Address(0x160) = %08lx\n",(UINT32)USB_DEV_EP1_IN_MAXPKS);
    printf("Address(0x164) = %08lx\n",(UINT32)USB_DEV_EP2_IN_MAXPKS);
    printf("Address(0x184) = %08lx\n",(UINT32)USB_DEV_EP2_OUT_MAXPKS);    
    printf("Address(0x100) = %08lx\n",(UINT32)USB_DEV_CONTROL);
    printf("Address(0x114) = %08lx\n",(UINT32)USB_PHY_TEST_MODE);
    printf("\n");
#endif
  
#endif

    /* USB�豸�����ж�ʹ������ */
    /* �ó���ʹ����ȫ���ж�,���Ը�����Ҫ�ر���Ӧ�ж� */
    USB_DEV_MASK_INT_GROP  = 0x00000000;                                        /* Enable USB Device interrupt of source group 0��1��2*/
    USB_DEV_MASK_INT_GROP0 = 0x00000000;
    USB_DEV_MASK_INT_GROP1 = 0x00000000;                                        /* FIFO0(ENDP1_IN)��FIFO1(ENDP2_IN)��FIFO2(ENDP2_OUT) */     
    USB_DEV_MASK_INT_GROP2 = 0x00000000;        


    /* ʹ��оƬ������(������Ҫ����ǿ������ȫ��ģʽ) */
    USB_DEV_CONTROL = RB_CHIP_EN | RB_GLINT_EN | RB_CAP_RMWAKUP;                /* ʹ��оƬ��ʹ��ȫ���жϡ�ʹ�ܸ��� */                  
    USBDev_SpeedSet( USB_DEV_SPEED_FS );                                        /* ǿ������ȫ��ģʽ */
    Delay_ms( 1 );                                                
    USB_PHY_TEST_MODE &= ~RB_UNPLUG;                                            /* �Ĵ���(0x114)λ0��0,֪ͨ�������� */
} 

/*******************************************************************************
* Function Name  : USB_Dev_SetAddress
* Description    : ����USB�豸��ַ
* Input          : addre---�豸��ַ
* Output         : None
* Return         : None
*******************************************************************************/

void USBDev_SetAddress( UINT8 addre )
{
    USB_DEV_ADDRESS = addre;
}

/*******************************************************************************
* Function Name  : USBDev_SetConfig
* Description    : ����USB�豸���ñ�־λ
*                  ע��: �����ڴ���SET_CONFIGURATION��������øñ�־λ,���򲻻���Ӧ
*                        �ǿ��ƶ˵�Ĵ���
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/

void USBDev_SetConfig( void )
{
    USB_DEV_ADDRESS |= RB_AFT_CONF;                                             /* �������ñ�־λ */     
}

/*******************************************************************************
* Function Name  : USB_Dev_GetSOFFrameNum
* Description    : ��ȡSOF֡��
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/

void USBDev_GetSOFFrameNum( void )
{
    printf("SOF USOFN = %lx\n",(UINT32)((USB_DEV_SOF_NUM >> 11) && 0x07 ) );        
    printf("SOF SOFN = %04lx\n",(UINT32)(USB_DEV_SOF_NUM  && 0x000007FF ) );        
}

/*******************************************************************************
* Function Name  : USBDev_EP0_Stall
* Description    : USB�豸��������STALL
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/

void USBDev_EP0_Stall( void )
{
    USB_DEV_CX_CONF_FIFO_STATUS |= RB_CX_STL;                                   /* reg=0x120 */    
}

/*******************************************************************************
* Function Name  : USBDev_EPx_IN_Stall
* Description    : USB�豸EPx��IN�˵�����STALL
* Input          : epx_num---�˵��(��ΧΪ:1---8)
*                  mode------ģʽ(1Ϊ����STALL, 0Ϊ���STALL)
* Output         : None
* Return         : None
*******************************************************************************/

void USBDev_EPx_IN_Stall( UINT8 epx_num, UINT8 mode )
{
    UINT32 addr;
    UINT32 reg;    
    
    addr = USB_BASE_ADDR + 0x160 +  4 * ( epx_num - 1 );
    reg  = (*((PUINT32V)addr));
    (*((PUINT32V)addr)) = reg | RB_STL_IEPx;        
}

/*******************************************************************************
* Function Name  : USBDev_EPx_OUT_Stall
* Description    : USB�豸EPx��OUT�˵�����STALL
* Input          : epx_num---�˵��(��ΧΪ:1---8)
*                  mode------ģʽ(1��Ϊ����STALL, 0Ϊ���STALL)
* Output         : None
* Return         : None
*******************************************************************************/

void USBDev_EPx_OUT_Stall( UINT8 epx_num, UINT8 mode )
{
    UINT32 addr;
    UINT32 reg;    
    
    addr = USB_BASE_ADDR + 0x180 +  4 * ( epx_num - 1 );
    reg  = (*((PUINT32V)addr));
    (*((PUINT32V)addr)) = reg | RB_STL_OEPx;        
}

/*******************************************************************************
* Function Name  : USBDev_EPx_IN_ResetToggle
* Description    : USB�豸EPx��IN�˵㸴λͬ��λ
* Input          : epx_num---�˵��(��ΧΪ:1---8)
* Output         : None
* Return         : None
*******************************************************************************/

void USBDev_EPx_IN_ResetToggle( UINT8 epx_num )
{
    UINT32 addr;
    UINT32 reg;    
    
    addr = USB_BASE_ADDR + 0x160 +  4 * ( epx_num - 1 );
    reg  = (*((PUINT32V)addr));
    (*((PUINT32V)addr)) = reg | RB_RSTG_IEPx;        
}

/*******************************************************************************
* Function Name  : USBDev_EPx_OUT_ResetToggle
* Description    : USB�豸EPx��OUT�˵㸴λͬ��λ
* Input          : epx_num---�˵��(��ΧΪ:1---8)
* Output         : None
* Return         : None
*******************************************************************************/

void USBDev_EPx_OUT_ResetToggle( UINT8 epx_num )
{
    UINT32 addr;
    UINT32 reg;    
    
    addr = USB_BASE_ADDR + 0x180 +  4 * ( epx_num - 1 );
    reg  = (*((PUINT32V)addr));
    (*((PUINT32V)addr)) = reg | RB_RSTG_OEPx;        
}

/*******************************************************************************
* Function Name  : USBDev_EPx_IN_SetMaxPKS
* Description    : ����USB�豸EPx��IN�˵���������
* Input          : epx_num---�˵��(��ΧΪ:1---8)
*                  maxpks_len---������С 
* Output         : None
* Return         : None
*******************************************************************************/

void USBDev_EPx_IN_SetMaxPKS( UINT8 epx_num, UINT16 maxpks_len )
{
    UINT32 addr;
    UINT32 reg;    
    
    maxpks_len = maxpks_len & 0X3FF;
    addr = USB_BASE_ADDR + 0x160 +  4 * ( epx_num - 1 );
    reg  = (*((PUINT32V)addr));
    (*((PUINT32V)addr)) = ( reg & 0xFFFFFC00 ) | maxpks_len;        
}

/*******************************************************************************
* Function Name  : USBDev_EPx_OUT_SetMaxPKS
* Description    : ����USB�豸EPx��OUT�˵���������
* Input          : epx_num---�˵��(��ΧΪ:1---8)
*                  maxpks_len---������С 
* Output         : None
* Return         : None
*******************************************************************************/

void USBDev_EPx_OUT_SetMaxPKS( UINT8 epx_num, UINT16 maxpks_len )
{
    UINT32 addr;
    UINT32 reg;    
    
    maxpks_len = maxpks_len & 0X3FF;
    addr = USB_BASE_ADDR + 0x180 +  4 * ( epx_num - 1 );
    reg  = (*((PUINT32V)addr));
    (*((PUINT32V)addr)) = ( reg & 0xFFFFFC00 ) | maxpks_len;        
}

/*******************************************************************************
* Function Name  : USBDev_EPx_Init
* Description    : USB�豸�˵�����
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/

void USBDev_EPx_Init( UINT8 epx_num, 
                      UINT8 epx_type,
                      UINT8 fifo_type, 
                      UINT8 fifo_dir, 
                      UINT8 fifo_bk_num, 
                      UINT8 fifo_bk_size, 
                      UINT8 fifo_num, 
                      UINT8 fifo_en,
                      UINT16 maxpks_len )
{    
    UINT32 addr;
    UINT32 reg1, reg2, mask;    
    
    /* ���øö˵�IN��OUT����������С */
    if( epx_type == ENDP_TYPE_IN )
    {    
        USBDev_EPx_IN_SetMaxPKS( epx_num, maxpks_len );                         /* ����EPx_IN�˵��С */
    }
    else if( epx_type == ENDP_TYPE_OUT )
    {
        USBDev_EPx_OUT_SetMaxPKS( epx_num, maxpks_len );                        /* ����EPx_OUT�˵��С */
    }        

    /* ���øö˵�IN��OUT��Ӧ��FIFO�� */
    /* ����Endpoint1-4 Map Register(Addr=0X1A0)�Լ�Endpoint5-8 Map Register(Addr=0X1A4)*/    
    if( epx_num <= 4 )
    {
        addr = USB_BASE_ADDR + 0x1A0;    
    }
    else
    {
        addr = USB_BASE_ADDR + 0x1A4;            
        epx_num = epx_num - 4;
    }    
    reg1 = (*((PUINT32V)addr));                                                 /* ��ȡ�Ĵ���0X1A0��0X1A4ԭ����ֵ */

    mask = 0x00000003;
    reg2 = fifo_num;
    if( epx_type == ENDP_TYPE_OUT )
    {    
        mask = mask << 4;
        reg2 = reg2 << 4;
    }    
    if( epx_num == ENDP1 )
    {    
    }
    else if( epx_num == ENDP2 )
    {
        reg2 = reg2 << 8;
        mask = mask << 8;                         
    }    
    else if( epx_num == ENDP3 )
    {
        reg2 = reg2 << 16;
        mask = mask << 16;                                     
    }    
    else if( epx_num == ENDP4 )
    {
        reg2 = reg2 << 24;
        mask = mask << 24;                                     
    }            
    reg1 = ( reg1 & ( ~mask ) ) | reg2;    
    reg1 = reg1 & 0x33333333;
    (*((PUINT32V)addr)) = reg1;        

    /* ����FIFO Map Register(Addr=0X1A8) */
    mask = 0x000000FF;
    reg2 = ( ( fifo_dir & 0x03 ) << 4 ) | epx_num;
    if( fifo_num == FIFO_NUM_0 )
    {        
    }    
    else if( fifo_num == FIFO_NUM_1 )
    {        
        mask = mask << 8;            
        reg2 = reg2 << 8;
    }    
    else if( fifo_num == FIFO_NUM_2 )
    {        
        mask = mask << 16;            
        reg2 = reg2 << 16;
    }    
    else if( fifo_num == FIFO_NUM_3 )
    {        
        mask = mask << 24;            
        reg2 = reg2 << 24;
    }    
    reg1 = USB_DEV_FIFO_MAP;    
    USB_DEV_FIFO_MAP = ( reg1 & ( ~mask ) ) | reg2;        
    
    /* ����FIFO Configuration Register(Addr=0X1AC) */    
    mask = 0x000000FF;
    reg2 = fifo_type | ( ( fifo_bk_num & 0x03 ) << 2 ) | ( fifo_bk_size << 4 ) | ( fifo_en << 5 );    
    if( fifo_num == FIFO_NUM_0 )
    {        
    }    
    else if( fifo_num == FIFO_NUM_1 )
    {        
        mask = mask << 8;    
        reg2 = reg2 << 8;
    }    
    else if( fifo_num == FIFO_NUM_2 )
    {        
        mask = mask << 16;    
        reg2 = reg2 << 16;
    }    
    else if( fifo_num == FIFO_NUM_3 )
    {        
        mask = mask << 24;    
        reg2 = reg2 << 24;
    }        
    reg1 = USB_DEV_FIFO_CONFIG;    
    USB_DEV_FIFO_CONFIG = ( reg1 & ( ~mask ) ) | reg2;                        
}

/*******************************************************************************
* Function Name  : USBDev_RD_FIFOx
* Description    : ��FIFO�ж�ȡUSB����
* Input          : fifonum---FIFO��
*                  len-------�������ݳ���
*                   *pbuf-----���ݴ洢������    
* Output         : None
* Return         : len---ʵ�ʶ�ȡ����
*******************************************************************************/

UINT32 USBDev_RD_FIFOx( UINT8 fifonum, UINT32 len, UINT8 *pbuf )
{
    UINT32 i;
    UINT32 dat;
    
    i = 0;
    i = i;
    if( ( fifonum != USB_DMA_ACC_F0 ) && ( fifonum != USB_DMA_ACC_F1 ) &&
        ( fifonum != USB_DMA_ACC_F2 ) && ( fifonum != USB_DMA_ACC_F3 ) &&
        ( fifonum != USB_DMA_ACC_CXF ) )
    {
        USB_DEV_DMA_TARGET_FIFO = USB_DMA_ACC_NO;                               /* ����DMA����Ӧ�κ�FIFO */
        return( 0x00 );
    }
    USB_DEV_DMA_TARGET_FIFO = fifonum;                                          /* ����DMA��Ӧ��FIFO */
    if( fifonum == USB_DMA_ACC_CXF )                                            /* SETUP������ֱ�Ӷ�ȡ */
    {
        if( len > 8 )                                                           /* ���Ƴ��� */
        {    
            len = 8;                                
        }        
        for( i = 0; i < len / 4; i++ )
        {
            dat = USB_DEV_SETUP_CMD_RPORT;
            *pbuf++ = ( UINT8 )( dat );
             *pbuf++ = ( UINT8 )( dat >> 8 );
            *pbuf++ = ( UINT8 )( dat >> 16 );
            *pbuf++ = ( UINT8 )( dat >> 24 );                                   /* ��С�˽��� */
        }
    }
    else
    {
        if( USB_DEV_DMA_SET1 & RB_DMA_ABORT )                                   /* �ж��Ƿ���DMA_ABORT */
        {
            USB_DEV_DMA_SET1 |= RB_CLRFIFO_DMAABORT;    
            len = 0x00;                            
        }
        else
        {        
            /* ��FIFO x Instruction and Byte Count Register(0X1B0--0X1BC)�ж�ȡ��ӦFIFO���ݵĳ��� */    
            if( fifonum == USB_DMA_ACC_F0 )
            {
                i = USB_DEV_FIFO0_INFO;                                            
            }
            else if( fifonum == USB_DMA_ACC_F1 )
            {
                i = USB_DEV_FIFO1_INFO;                                        
            }            
            else if( fifonum == USB_DMA_ACC_F2 )
            {
                i = USB_DEV_FIFO2_INFO;                                        
            }            
            else if( fifonum == USB_DMA_ACC_F3 )
            {
                i = USB_DEV_FIFO3_INFO;                                        
            }
            if( len > i )
            {
                len = i;                                                        /* ��ȡ���ȴ���ʵ�ʳ���,��ȡʵ�ʳ��� */
            }                                                    
            /* ͨ��DMA�����ݴ�RAM����FIFO */
            USB_DEV_DMA_SET1 = len << 8;                                        /* ����USB DMAͨ�ų��� */
            USB_DEV_DMA_SET2 = (UINT32)pbuf;                                    /* ����USB DMAͨ�Ż�������ʼ��ַ */    
            USB_DEV_DMA_SET1 = USB_DEV_DMA_SET1 | RB_DMA_START;                 /* ����USB DMA����FIFO���ݴ��� */
            while( USB_DEV_DMA_SET1 & RB_DMA_START );                           /* �ȴ�DMA������� */
            USB_DEV_INT_GROP2 = USB_DEV_INT_GROP2 | RB_DMA_CMPLT;               /* ��DMA��ɱ�־ */        
        }
    }
    USB_DEV_DMA_TARGET_FIFO = USB_DMA_ACC_NO;                                    /* ����DMA����Ӧ�κ�FIFO */
    return( len );        
}

/*******************************************************************************
* Function Name  : USBDev_WR_FIFOx
* Description    : ��FIFO��д��USB����
* Input          : fifonum---FIFO��
*                  len-------�������ݳ���
*                   *pbuf-----���ݴ洢������    
* Output         : None
* Return         : len---д�볤��
*******************************************************************************/

UINT32 USBDev_WR_FIFOx( UINT8 fifonum, UINT32 len, UINT8 *pbuf )
{
    if( ( fifonum != USB_DMA_ACC_F0 ) && ( fifonum != USB_DMA_ACC_F1 ) &&
        ( fifonum != USB_DMA_ACC_F2 ) && ( fifonum != USB_DMA_ACC_F3 ) &&
        ( fifonum != USB_DMA_ACC_CXF ) )
    {
        USB_DEV_DMA_TARGET_FIFO = USB_DMA_ACC_NO;                                /* ����DMA����Ӧ�κ�FIFO */
        return( 0x00 );
    }
    if( USB_DEV_DMA_SET1 & RB_DMA_ABORT )                                        /* �ж��Ƿ���DMA_ABORT */
    {
        USB_DEV_DMA_SET1 = RB_CLRFIFO_DMAABORT;    
        return( 0x00 );                            
    }
    else
    {        
        /* ͨ��DMA�����ݴ�FIFO����RAM */
        USB_DEV_DMA_TARGET_FIFO = fifonum;                                      /* ����USB DMA��Ӧ��FIFO */                                                 
        USB_DEV_DMA_SET1 = ( len  << 8 ) | RB_DMA_TYPE;                         /* ����USB DMAͨ�ų��� */
        USB_DEV_DMA_SET2 = ( UINT32 )pbuf;                                      /* ����USB DMAͨ�Ż�������ʼ��ַ */    
        USB_DEV_DMA_SET1 = USB_DEV_DMA_SET1 | RB_DMA_START;                     /* ����USB DMA����FIFO���ݴ��� */
        while( ( USB_DEV_DMA_SET1 & RB_DMA_START ) );                           /* �ȴ�DMA������� */
        USB_DEV_INT_GROP2 = USB_DEV_INT_GROP2 | RB_DMA_CMPLT;                   /* ��DMA��ɱ�־ */    
        USB_DEV_DMA_TARGET_FIFO = USB_DMA_ACC_NO;                               /* ����DMA����Ӧ�κ�FIFO */
        return( len );        
    }        
}

/*******************************************************************************
* Function Name  : USBDev_EP0_Setup_Deal
* Description    : USB���ƶ˵�Setup������
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/

void USBDev_EP0_Setup_Deal( void )
{
    UINT32 len;
    UINT32 status;    
    UINT8  buf[ 8 ];
    USB_SETUP_REQ SetupReqBuf;

    /* ��ȡSETUP�� */    
    len = USBDev_RD_FIFOx( USB_DMA_ACC_CXF, 8, (PUINT8)&SetupReqBuf );          /* ��FIFO4�ж�ȡSETUP�� */
    if( len == sizeof( USB_SETUP_REQ ) )                                        /* �жϳ����Ƿ���Setup������ */
    {
        gSetupLen = SetupReqBuf.wLengthL;
        if( SetupReqBuf.wLengthH || gSetupLen > 0x7F ) 
        {
            gSetupLen = 0x7F;                                                   /* �����ܳ��� */
        }
        
        /* ������������ǰSETUP�� */
        len = 0;                                                                /* Ĭ���ϴ�����Ϊ0 */
        status = 0x00;                                                          /* Ĭ�ϲ���Ϊ�ɹ�״̬ */    
        if( ( SetupReqBuf.bReqType & USB_REQ_TYPE_MASK ) != USB_REQ_TYPE_STAND ) 
        {  
            /* ���������������󣬲�������� */
            status = 0xFF;                                                      /* ����ʧ�� */
        }
        else 
        {  
            /* ��׼���� */
            gSetupReq = SetupReqBuf.bRequest;                                   /* �ݴ浱ǰ������ */
            switch( gSetupReq ) 
            {
                case USB_REQ_GET_DESCR:                                         /* CMD: GET_DESCR */
                    switch( SetupReqBuf.wValueH ) 
                    {
                        case 1:
                            pDescr = (PUINT8)( &MyDevDescr[ 0 ] );
                            len = sizeof( MyDevDescr );
                            USBDev_SpeedCheck(  );                              /* �жϵ�ǰUSB�豸�ٶ� */
                            break;
                        
                        case 2:
                            if( gUsbSpeed == 0x00 )                             /* ����ģʽ */
                            {
                                pDescr = (PUINT8)( &My_HS_CfgDescr[ 0 ] );
                                len = sizeof( My_HS_CfgDescr );
                                
                                /* ����������Ӧ�˵��С */                                
                                USBDev_EPx_IN_SetMaxPKS( ENDP1, 64 );
                                USBDev_EPx_IN_SetMaxPKS( ENDP2, 512 );
                                USBDev_EPx_OUT_SetMaxPKS( ENDP2, 512 );                                
                            }
                            else                                                /* ȫ��ģʽ */        
                            {
                                pDescr = (PUINT8)( &My_FS_CfgDescr[ 0 ] );
                                len = sizeof( My_FS_CfgDescr );
                            }
                            break;
                        
                        case 3:
                            switch( SetupReqBuf.wValueL ) 
                            {
                                case 1:
                                    pDescr = (PUINT8)( &MyManuInfo[ 0 ] );
                                    len = sizeof( MyManuInfo );
                                    break;
                                    
                                case 2:
                                    pDescr = (PUINT8)( &MyProdInfo[ 0 ] );
                                    len = sizeof( MyProdInfo );
                                    break;
                                    
                                case 0:
                                    pDescr = (PUINT8)( &MyLangDescr[ 0 ] );
                                    len = sizeof( MyLangDescr );
                                    break;
                                
                                default:
                                    status = 0xFF;                              /* ����ʧ�� */
                                    break;
                            }
                            break;
                        
                        default:
                            status = 0xFF;                                      /* ����ʧ�� */
                            break;
                    }
                    
                    if ( gSetupLen > len ) 
                    {
                        gSetupLen = len;                                        /* �����ܳ��� */
                    }
                    len = gSetupLen >= USB_EP0_MAX_PKT ? 
                          USB_EP0_MAX_PKT : gSetupLen;                          /* ���δ��䳤�� */
                    USBDev_WR_FIFOx( USB_DMA_ACC_CXF, len, pDescr );            /* �����ϴ����ݵ�FIFO 4 */
                    gSetupLen -= len;
                    pDescr += len;
                    break;
                                
                case USB_REQ_SET_ADDRESS:                                       /* CMD: SET_ADDRESS */    
                    gSetupLen = SetupReqBuf.wValueL;                            /* �ݴ�USB�豸��ַ */                
                    USBDev_WR_FIFOx( USB_DMA_ACC_CXF, 0x00, pDescr );           /* �ϴ�0�ֽ����� */
                    USBDev_SetAddress( gSetupLen );                             /* ���õ�ַ */    
                    break;
                                
                case USB_REQ_GET_CONFIG:                                        /* CMD: GET_CONFIG */
                    buf[ 0 ] = gUsbConfig;
                    if ( gSetupLen >= len ) 
                    {
                        len = 0x01;
                    }
                    USBDev_WR_FIFOx( USB_DMA_ACC_CXF, len, buf );               /* �����ϴ����ݵ�FIFO 4 */
                    break;
                                
                case USB_REQ_SET_CONFIG:                                        /* CMD: SET_CONFIG */
                    gUsbConfig = SetupReqBuf.wValueL;
                    USBDev_SetConfig( );                                        /* ����USB����λ */
                    break;
                                
                case USB_REQ_CLR_FEATURE:                                       /* CMD: CLR_FEATURE */
                    if( ( SetupReqBuf.bReqType & 0x1F ) == 0x02 ) 
                    {      
                        /* ���Ƕ˵㲻֧�� */
                        switch( SetupReqBuf.wIndexL ) 
                        {
                            case 0x82:
                                break;
                            
                            case 0x02:
                                break;
                            
                            case 0x81:
                                break;
                            
                            case 0x01:
                                break;
                            
                            default:
                                status = 0xFF;                                  /* ����ʧ�� */
                                break;
                        }
                    }
                    else
                    {
                        status = 0xFF;                                          /* ����ʧ�� */
                    }
                    break;
                                
                case USB_REQ_GET_INTERF:                                        /* CMD: GET_INTERF */
                    buf[ 0 ] = 0x00;
                    if ( gSetupLen >= 1 ) 
                    {
                        len = 1;
                    }
                    USBDev_WR_FIFOx( USB_DMA_ACC_CXF, len, buf );               /* �����ϴ����ݵ�FIFO 4 */
                    break;
                                
                case USB_REQ_GET_STATUS:                                        /* CMD: GET_STATUS */
                    buf[ 0 ] = 0x00;
                    buf[ 1 ] = 0x00;                     
                    if( gSetupLen >= 2 ) 
                    {
                        len = 2;
                    }
                    else 
                    {
                        len = gSetupLen;
                    }
                    USBDev_WR_FIFOx( USB_DMA_ACC_CXF, len, buf );               /* �����ϴ����ݵ�FIFO 4 */
                    break;
                                
                default:
                    status = 0xFF;                                              /* ����ʧ�� */
                    break;
            }
        }
    }
    else 
    {
        status = 0xFF;                                                          /* ����ʧ�� */
    }
    
    if( status == 0xFF ) 
    {  
        /* ����ʧ�� */
        USBDev_EP0_Stall( );                                                    /* �˵�0����STALL */
    }
    else
    {
        USB_DEV_CX_CONF_FIFO_STATUS |= RB_DONE;                                 /* �����˵�0�������ݴ��� */        
    }    
}

/*******************************************************************************
* Function Name  : USBDev_EP0_IN_Deal
* Description    : USB���ƶ˵�IN������
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/

void USBDev_EP0_IN_Deal( void )
{
    UINT32 len;
    
    switch( gSetupReq ) 
    {
        case USB_REQ_GET_DESCR:
            len = gSetupLen >= USB_EP0_MAX_PKT ? USB_EP0_MAX_PKT : gSetupLen;   /* ���δ��䳤�� */
            USBDev_WR_FIFOx( USB_DMA_ACC_CXF, len, pDescr );                    /* �����ϴ����� */
            gSetupLen -= len;
            pDescr += len;
            USB_DEV_CX_CONF_FIFO_STATUS |=     RB_DONE;                            /* �����˵�0�������ݴ��� */    
            break;
            
        case USB_REQ_SET_ADDRESS:
            USBDev_SetAddress( gSetupLen );                                     /* ����USB��ַ�Ĵ��� */    
            
        default:
            break;
    }
}

/*******************************************************************************
* Function Name  : USBDev_EP0_OUT_Deal
* Description    : USB���ƶ˵�OUT������
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/

void USBDev_EP0_OUT_Deal( void )
{
    
}

/*******************************************************************************
* Function Name  : USBDev_EP2_OUT_Deal
* Description    : USB�˵�2 OUT������
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/

void USBDev_EP2_OUT_Deal( void )
{
    UINT8  buf[ 512 ];
    UINT32 i, len;

    /* ���´�����������ȡ���� */
    len = USBDev_RD_FIFOx( USB_DMA_ACC_F2, 512, buf );                          /* ��ȡEP2_OUT�� */                

    /* ��ʾ���ݰ��ش� */
    for( i = 0; i < len; i++ )
    {
        buf[ i ] = ~buf[ i ];
    }
    USBDev_WR_FIFOx( USB_DMA_ACC_F1, len, buf );                                /* �ش�ΪEP2_IN */                                        
}
                            
/*******************************************************************************
* Function Name  : USBDev_IRQHandler
* Description    : USB�жϴ���
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/

void USBDev_IRQHandler( void )
{
    UINT32 grp_int, intstatus;

    /* �ж��Ƿ���USB�豸�жϲ���,������ */    
    if( USB_GL_INT_STATUS == 0x01 )                                             /* �ж��Ƿ���USB�豸�жϲ��� */
    {
        USB_GL_INT_STATUS = USB_GL_INT_STATUS | 0x01;                           /* ��λд1��0 */  

        grp_int = USB_DEV_INT_GROP;                                             /* ��ȡ����USB�жϵ��ж�Դ */
        if( grp_int & 0x01 )                                                    /* grop0: control transfer interrupt */
        {
            intstatus = USB_DEV_INT_GROP0; 
            if( intstatus & RB_CX_COMABORT_INT  )                               /* R(0x140)λ5�� ���ƴ���ʧ�� */
            {        
                USB_DEV_INT_GROP0 = intstatus | RB_CX_COMABORT_INT;             /* ��USB�˵�0 OUT�ж�(д1��0) */                        
            }    
            if( intstatus & RB_CX_COMFAIL_INT )                                 /* R(0x140)λ4�����ƶ˵����IN��OUTʧ�� */
            {
                /* ���ж�λֻ��,��Ӳ����0 */                
                USBDev_EP0_Stall( );                                            /* �˵�0����STALL */
            }
            if( intstatus & RB_CX_COMEND )                                      /* R(0x140)λ3������״̬�׶� */
            {
                /* ���ƴ������״̬�׶� */
                
                /* ���ж�λֻ��,��Ӳ����0 */
                USB_DEV_CX_CONF_FIFO_STATUS |= RB_DONE;                    
            }
            if( intstatus & RB_CX_OUT_INT )                                     /* R(0x140)λ2�����ƶ˵�OUT�ж� */
            {                
                /* ���ƶ˵�OUT�жϴ��� */                                    
                USBDev_EP0_OUT_Deal( );        
                        
                /* ���ж�λֻ��,��Ӳ����0 */
            }
            if( intstatus & RB_CX_IN_INT )                                      /* R(0x140)λ1�����ƶ˵�IN�ж� */
            {
                /* ���ƶ˵�IN�жϴ��� */                                
                USBDev_EP0_IN_Deal( );
                
                /* ���ж�λֻ��,��Ӳ����0 */
            }
            if( intstatus & RB_CX_SETUP_INT )                                   /* R(0x140)λ0�����ƶ˵�SETUP�ж� */
            {
                /* ���ƶ˵�SETUP�жϴ��� */
                USBDev_EP0_Setup_Deal( );
                
                /* ���ж�λֻ��,��Ӳ����0 */
            }                        
        }    
        if( grp_int & 0x02 )                                                    /* grop1: bulk/ISO/Interrupt interrupt */
        {
            intstatus = USB_DEV_INT_GROP1; 

            /* �üĴ��������ж�λΪֻ��,��Ӳ����0 */
            if( intstatus & RB_F3_IN_INT )                                      /* FIFO3 IN interrupt */
            {                    
            }
            if( intstatus & RB_F2_IN_INT )                                      /* FIFO2 IN interrupt */
            {                
            }
            if( intstatus & RB_F1_IN_INT )                                      /* FIFO1 IN interrupt */
            {    
                /* �ϴ��ٶȲ���,���´�һ������,Ȼ��һֱ�ϴ����ݰ� */
#if 0
                if( Speed_Test_Flag )
                {
                    if( gUsbSpeed == 0 )
                    {
//                        USBDev_WR_FIFOx( USB_DMA_ACC_F1, 512, buf );          /* ���ٻش�ΪEP2_IN */    

                        /* ͨ��DMA�����ݴ�FIFO����RAM */
                        USB_DEV_DMA_TARGET_FIFO = USB_DMA_ACC_F1;               /* ����USB DMA��Ӧ��FIFO */                                                 
                        USB_DEV_DMA_SET1 = ( 512 << 8 ) | RB_DMA_TYPE;          /* ����USB DMAͨ�ų��� */
                        USB_DEV_DMA_SET2 = (UINT32)buf;                         /* ����USB DMAͨ�Ż�������ʼ��ַ */    
                        USB_DEV_DMA_SET1 = USB_DEV_DMA_SET1 | RB_DMA_START;     /* ����USB DMA����FIFO���ݴ��� */
                        while( ( USB_DEV_DMA_SET1 & RB_DMA_START ) );           /* �ȴ�DMA������� */
                        USB_DEV_INT_GROP2 = USB_DEV_INT_GROP2 | RB_DMA_CMPLT;   /* ��DMA��ɱ�־ */    
                        USB_DEV_DMA_TARGET_FIFO = USB_DMA_ACC_NO;               /* ����DMA����Ӧ�κ�FIFO */
                    }
                    else
                    {
//                        USBDev_WR_FIFOx( USB_DMA_ACC_F1, 64, buf );             /* ȫ�ٻش�ΪEP2_IN */    

                        /* ͨ��DMA�����ݴ�FIFO����RAM */
                        USB_DEV_DMA_TARGET_FIFO = USB_DMA_ACC_F1;               /* ����USB DMA��Ӧ��FIFO */                                                 
                        USB_DEV_DMA_SET1 = ( 64 << 8 ) | RB_DMA_TYPE;           /* ����USB DMAͨ�ų��� */
                        USB_DEV_DMA_SET2 = (UINT32)buf;                         /* ����USB DMAͨ�Ż�������ʼ��ַ */    
                        USB_DEV_DMA_SET1 = USB_DEV_DMA_SET1 | RB_DMA_START;     /* ����USB DMA����FIFO���ݴ��� */
                        while( ( USB_DEV_DMA_SET1 & RB_DMA_START ) );           /* �ȴ�DMA������� */
                        USB_DEV_INT_GROP2 = USB_DEV_INT_GROP2 | RB_DMA_CMPLT;   /* ��DMA��ɱ�־ */    
                        USB_DEV_DMA_TARGET_FIFO = USB_DMA_ACC_NO;               /* ����DMA����Ӧ�κ�FIFO */
                    }
                }
#endif
            }
            if( intstatus & RB_F0_IN_INT )                                      /* FIFO0 IN interrupt */
            {                        
            }
            if( intstatus & RB_F3_SPK_INT )                                     /* FIFO3 Short OUT interrupt */
            {
            }
            if( intstatus & RB_F3_OUT_INT )                                     /* FIFO3 OUT interrupt */
            {
            }
            if( intstatus & RB_F2_SPK_INT )                                     /* FIFO2 Short OUT interrupt */
            {
            }
            if( intstatus & RB_F2_OUT_INT )                                     /* FIFO2 OUT interrupt */
            {                
                USBDev_EP2_OUT_Deal( );
                Speed_Test_Flag = 1;                                            /* �����ٶȲ��Կ�ʼ��־ */ 
            }
            if( intstatus & RB_F1_SPK_INT )                                     /* FIFO1 Short OUT interrupt */
            {
            }
            if( intstatus & RB_F1_OUT_INT )                                     /* FIFO1 OUT interrupt */
            {
            }
            if( intstatus & RB_F0_SPK_INT )                                     /* FIFO0 Short OUT interrupt */
            {
            }
            if( intstatus & RB_F0_OUT_INT )                                     /* FIFO0 OUT interrupt */
            {
            }
        }
        if( grp_int & 0x04 )                                                    /* grop2: bulk/ISO/Interrupt interrupt */ 
        {
            intstatus = USB_DEV_INT_GROP2; 
            if( intstatus & RB_DEV_WAKEUP_BYBUS )                               /* Dev_Wakeup_byVBUS interrupt */
            {                
                /* �豸��VBUS�����ж� */
                /* ���ж�λֻ��,��Ӳ����0 */                
            }            
            if( intstatus & RB_DEV_IDLE )                                       /* Dev_Idle interrupt */
            {                
                /* �豸�����ж� */
                /* ���ж�λֻ��,��Ӳ����0 */                
            }            
            if( intstatus & RB_DMA_ERROR )                                      /* DMA Error interrupt */
            {                
                /* DMA�����ж� */
                USB_DEV_INT_GROP2 = RB_DMA_ERROR;                               /* ��DMA�����ж�(д1��0) */                                
            }            
            if( intstatus & RB_DMA_CMPLT )                                      /* DMA Completion interrupt */
            {                
                /* DMA��������ж� */
                USB_DEV_INT_GROP2 = RB_DMA_CMPLT;                               /* ��DMA��������ж�(д1��0) */                
            }            
            if( intstatus & RB_RX0BYTE_INT )                                    /* Received Zero-length Data Packet interrupt */
            {                
                /* ����0�������ݰ��ж� */
                USB_DEV_INT_GROP2 = RB_RX0BYTE_INT;                             /* �����0�������ݰ��ж�(д1��0) */
            }            
            if( intstatus & RB_TX0BYTE_INT )                                    /* Transferred Zero-length Data Packet interrupt */
            {                
                /* ����0�������ݰ��ж� */
                USB_DEV_INT_GROP2 = RB_TX0BYTE_INT;                             /* �巢��0�������ݰ��ж�(д1��0) */            
            }            
            if( intstatus & RB_ISO_SEQ_ABORT_INT )                              /* ISO Sequential Abort interrupt */
            {                                
                /* USB ISO�쳣�ж� */
                USB_DEV_INT_GROP2 = RB_ISO_SEQ_ERR_INT;                         /* ��USB ISO�쳣�ж�(д1��0) */            
            }            
            if( intstatus & RB_ISO_SEQ_ERR_INT )                                /* ISO Sequential Error interrupt */
            {            
                /* USB ISO�����ж� */
                USB_DEV_INT_GROP2 = RB_ISO_SEQ_ERR_INT;                         /* ��USB ISO�����ж�(д1��0) */            
            }            
            if( intstatus & RB_RESMQ_INT )                                      /* Resume interrupt */
            {                
                /* USB���߻ָ��ж� */
                USB_DEV_INT_GROP2 = RB_RESMQ_INT;                               /* ��USB���߻ָ��ж�(д1��0) */            
            }
            if( intstatus & RB_SUSP_INT )                                       /* Suspend interrupt */
            {
                /* USB���߹����ж� */
                USB_DEV_INT_GROP2 = RB_SUSP_INT;                                /* ��USB���߹����ж�(д1��0) */            
            }            
            if( intstatus & RB_USBRST_INT )                                     /* USB Reset interrupt */
            {    
                USB_DEV_INT_GROP2 = RB_USBRST_INT;            
                /* USB���߸�λ,�Զ����ַ */                
                USBDev_SetAddress( 0x00 );                                      /* ��USB�豸��ַ(ʵ�ʸ�λʱ�Զ���0) */            
            }            
        }
    }
}

/*********************************** endfile **********************************/
